﻿Imports MySql.Data.MySqlClient
Module Variables
    Public conn As MySqlConnection
    Public com As MySqlCommand
    Public dset As New DataTable
    Public usertype As String
    Public dbcon As String
    Public sfamily As String
End Module
