﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Adminfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.FolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DateModifiedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SortbyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmallIconToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ScreenResolutionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GadgetsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PersonalizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AccountsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewUserAccountToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MangeUserAccountsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageMedicinesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfMedicinesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemainingStocksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MedicalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefferalLetterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfSuppliersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfMedicineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfMedicineDistributionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfSuppliersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfDoctorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListsOfSuppliersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataBaseConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateBackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RetrieveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FolderToolStripMenuItem
        '
        Me.FolderToolStripMenuItem.Name = "FolderToolStripMenuItem"
        Me.FolderToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.FolderToolStripMenuItem.Text = "Folder"
        '
        'WordToolStripMenuItem
        '
        Me.WordToolStripMenuItem.Name = "WordToolStripMenuItem"
        Me.WordToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.WordToolStripMenuItem.Text = "Word"
        '
        'TextToolStripMenuItem
        '
        Me.TextToolStripMenuItem.Name = "TextToolStripMenuItem"
        Me.TextToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.TextToolStripMenuItem.Text = "Text"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TextToolStripMenuItem, Me.WordToolStripMenuItem, Me.FolderToolStripMenuItem})
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'DateModifiedToolStripMenuItem
        '
        Me.DateModifiedToolStripMenuItem.Name = "DateModifiedToolStripMenuItem"
        Me.DateModifiedToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.DateModifiedToolStripMenuItem.Text = "Date modified"
        '
        'ItemTypeToolStripMenuItem
        '
        Me.ItemTypeToolStripMenuItem.Name = "ItemTypeToolStripMenuItem"
        Me.ItemTypeToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.ItemTypeToolStripMenuItem.Text = "Item type"
        '
        'SizeToolStripMenuItem
        '
        Me.SizeToolStripMenuItem.Name = "SizeToolStripMenuItem"
        Me.SizeToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.SizeToolStripMenuItem.Text = "Size"
        '
        'NameToolStripMenuItem
        '
        Me.NameToolStripMenuItem.Name = "NameToolStripMenuItem"
        Me.NameToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.NameToolStripMenuItem.Text = "Name"
        '
        'SortbyToolStripMenuItem
        '
        Me.SortbyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NameToolStripMenuItem, Me.SizeToolStripMenuItem, Me.ItemTypeToolStripMenuItem, Me.DateModifiedToolStripMenuItem})
        Me.SortbyToolStripMenuItem.Name = "SortbyToolStripMenuItem"
        Me.SortbyToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.SortbyToolStripMenuItem.Text = "Sortby"
        '
        'SmallIconToolStripMenuItem
        '
        Me.SmallIconToolStripMenuItem.Name = "SmallIconToolStripMenuItem"
        Me.SmallIconToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.SmallIconToolStripMenuItem.Text = "Small Icon"
        '
        'DateToolStripMenuItem
        '
        Me.DateToolStripMenuItem.Name = "DateToolStripMenuItem"
        Me.DateToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.DateToolStripMenuItem.Text = "Medium Icon"
        '
        'TypeToolStripMenuItem
        '
        Me.TypeToolStripMenuItem.Name = "TypeToolStripMenuItem"
        Me.TypeToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.TypeToolStripMenuItem.Text = "Large Icon"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TypeToolStripMenuItem, Me.DateToolStripMenuItem, Me.SmallIconToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewToolStripMenuItem, Me.SortbyToolStripMenuItem, Me.RefreshToolStripMenuItem, Me.NewToolStripMenuItem, Me.ScreenResolutionToolStripMenuItem, Me.GadgetsToolStripMenuItem, Me.PersonalizeToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(160, 158)
        '
        'ScreenResolutionToolStripMenuItem
        '
        Me.ScreenResolutionToolStripMenuItem.Name = "ScreenResolutionToolStripMenuItem"
        Me.ScreenResolutionToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.ScreenResolutionToolStripMenuItem.Text = "Scren resolution"
        '
        'GadgetsToolStripMenuItem
        '
        Me.GadgetsToolStripMenuItem.Name = "GadgetsToolStripMenuItem"
        Me.GadgetsToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.GadgetsToolStripMenuItem.Text = "Gadgets"
        '
        'PersonalizeToolStripMenuItem
        '
        Me.PersonalizeToolStripMenuItem.Name = "PersonalizeToolStripMenuItem"
        Me.PersonalizeToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.PersonalizeToolStripMenuItem.Text = "Personalize"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.DropShadowEnabled = False
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.White
        Me.ToolStrip1.BackgroundImage = Global.MEDICINE_INVENTORY.My.Resources.Resources.Toolbar_Bkg
        Me.ToolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ToolStrip1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton3, Me.ToolStripButton4, Me.ToolStripButton6, Me.ToolStripButton5, Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripButton7})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 28)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(915, 68)
        Me.ToolStrip1.TabIndex = 9
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.AutoSize = False
        Me.ToolStripButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ToolStripButton3.Checked = True
        Me.ToolStripButton3.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton3.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.pill_icon__1_
        Me.ToolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton3.Text = "Medicines"
        Me.ToolStripButton3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.AutoSize = False
        Me.ToolStripButton4.Checked = True
        Me.ToolStripButton4.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton4.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.sup2
        Me.ToolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton4.Text = "Suppliers"
        Me.ToolStripButton4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.AutoSize = False
        Me.ToolStripButton6.Checked = True
        Me.ToolStripButton6.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton6.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.Users
        Me.ToolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton6.Text = "Accounts"
        Me.ToolStripButton6.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.AutoSize = False
        Me.ToolStripButton5.Checked = True
        Me.ToolStripButton5.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton5.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.distribute
        Me.ToolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton5.Text = "Distribute"
        Me.ToolStripButton5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.AutoSize = False
        Me.ToolStripButton1.BackColor = System.Drawing.Color.White
        Me.ToolStripButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ToolStripButton1.Checked = True
        Me.ToolStripButton1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ToolStripButton1.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources._in
        Me.ToolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton1.Tag = "MEDICINES"
        Me.ToolStripButton1.Text = "Stocks In"
        Me.ToolStripButton1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        Me.ToolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.AutoSize = False
        Me.ToolStripButton2.Checked = True
        Me.ToolStripButton2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton2.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.OUT
        Me.ToolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton2.Text = "Stocks Out"
        Me.ToolStripButton2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.AutoSize = False
        Me.ToolStripButton7.Checked = True
        Me.ToolStripButton7.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton7.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.medical_report_icon1
        Me.ToolStripButton7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(75, 65)
        Me.ToolStripButton7.Text = "Distributed"
        Me.ToolStripButton7.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AllowMerge = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.MenuStrip1.BackgroundImage = Global.MEDICINE_INVENTORY.My.Resources.Resources.Button_Bkg
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountsToolStripMenuItem, Me.FileToolStripMenuItem, Me.TransactionsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.SystemToolsToolStripMenuItem, Me.AboutHelpToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.ShowItemToolTips = True
        Me.MenuStrip1.Size = New System.Drawing.Size(915, 28)
        Me.MenuStrip1.Stretch = False
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AccountsToolStripMenuItem
        '
        Me.AccountsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewUserAccountToolStripMenuItem1, Me.MangeUserAccountsToolStripMenuItem, Me.LogOutToolStripMenuItem1})
        Me.AccountsToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.keys
        Me.AccountsToolStripMenuItem.Name = "AccountsToolStripMenuItem"
        Me.AccountsToolStripMenuItem.Size = New System.Drawing.Size(99, 24)
        Me.AccountsToolStripMenuItem.Text = "Accounts"
        '
        'NewUserAccountToolStripMenuItem1
        '
        Me.NewUserAccountToolStripMenuItem1.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.add_user
        Me.NewUserAccountToolStripMenuItem1.Name = "NewUserAccountToolStripMenuItem1"
        Me.NewUserAccountToolStripMenuItem1.Size = New System.Drawing.Size(227, 24)
        Me.NewUserAccountToolStripMenuItem1.Text = "New User Account"
        '
        'MangeUserAccountsToolStripMenuItem
        '
        Me.MangeUserAccountsToolStripMenuItem.Name = "MangeUserAccountsToolStripMenuItem"
        Me.MangeUserAccountsToolStripMenuItem.Size = New System.Drawing.Size(227, 24)
        Me.MangeUserAccountsToolStripMenuItem.Text = "Mange User Accounts"
        '
        'LogOutToolStripMenuItem1
        '
        Me.LogOutToolStripMenuItem1.Name = "LogOutToolStripMenuItem1"
        Me.LogOutToolStripMenuItem1.Size = New System.Drawing.Size(227, 24)
        Me.LogOutToolStripMenuItem1.Text = "Log-Out"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataEntryToolStripMenuItem, Me.ManageMedicinesToolStripMenuItem, Me.AccountSettingsToolStripMenuItem, Me.LogoutToolStripMenuItem, Me.ListOfMedicinesToolStripMenuItem, Me.RemainingStocksToolStripMenuItem})
        Me.FileToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.pill_icon__1_
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(106, 24)
        Me.FileToolStripMenuItem.Text = "Medicines"
        '
        'DataEntryToolStripMenuItem
        '
        Me.DataEntryToolStripMenuItem.Name = "DataEntryToolStripMenuItem"
        Me.DataEntryToolStripMenuItem.Size = New System.Drawing.Size(207, 24)
        Me.DataEntryToolStripMenuItem.Text = "New Medicine Info"
        '
        'ManageMedicinesToolStripMenuItem
        '
        Me.ManageMedicinesToolStripMenuItem.Name = "ManageMedicinesToolStripMenuItem"
        Me.ManageMedicinesToolStripMenuItem.Size = New System.Drawing.Size(207, 24)
        Me.ManageMedicinesToolStripMenuItem.Text = "Manage Medicines"
        '
        'AccountSettingsToolStripMenuItem
        '
        Me.AccountSettingsToolStripMenuItem.Name = "AccountSettingsToolStripMenuItem"
        Me.AccountSettingsToolStripMenuItem.Size = New System.Drawing.Size(207, 24)
        Me.AccountSettingsToolStripMenuItem.Text = "Add Stocks"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(207, 24)
        Me.LogoutToolStripMenuItem.Text = "Distribute"
        '
        'ListOfMedicinesToolStripMenuItem
        '
        Me.ListOfMedicinesToolStripMenuItem.Name = "ListOfMedicinesToolStripMenuItem"
        Me.ListOfMedicinesToolStripMenuItem.Size = New System.Drawing.Size(207, 24)
        Me.ListOfMedicinesToolStripMenuItem.Text = "List of Medicines"
        '
        'RemainingStocksToolStripMenuItem
        '
        Me.RemainingStocksToolStripMenuItem.Name = "RemainingStocksToolStripMenuItem"
        Me.RemainingStocksToolStripMenuItem.Size = New System.Drawing.Size(207, 24)
        Me.RemainingStocksToolStripMenuItem.Text = "Remaining Stocks"
        '
        'TransactionsToolStripMenuItem
        '
        Me.TransactionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MedicalToolStripMenuItem, Me.RefferalLetterToolStripMenuItem, Me.ListOfSuppliersToolStripMenuItem1})
        Me.TransactionsToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.sup2
        Me.TransactionsToolStripMenuItem.Name = "TransactionsToolStripMenuItem"
        Me.TransactionsToolStripMenuItem.Size = New System.Drawing.Size(100, 24)
        Me.TransactionsToolStripMenuItem.Text = "Suppliers"
        '
        'MedicalToolStripMenuItem
        '
        Me.MedicalToolStripMenuItem.Name = "MedicalToolStripMenuItem"
        Me.MedicalToolStripMenuItem.Size = New System.Drawing.Size(201, 24)
        Me.MedicalToolStripMenuItem.Text = "New Supllier Info"
        '
        'RefferalLetterToolStripMenuItem
        '
        Me.RefferalLetterToolStripMenuItem.Name = "RefferalLetterToolStripMenuItem"
        Me.RefferalLetterToolStripMenuItem.Size = New System.Drawing.Size(201, 24)
        Me.RefferalLetterToolStripMenuItem.Text = "Manage Suppliers"
        '
        'ListOfSuppliersToolStripMenuItem1
        '
        Me.ListOfSuppliersToolStripMenuItem1.Name = "ListOfSuppliersToolStripMenuItem1"
        Me.ListOfSuppliersToolStripMenuItem1.Size = New System.Drawing.Size(201, 24)
        Me.ListOfSuppliersToolStripMenuItem1.Text = "List of Suppliers"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListOfMedicineToolStripMenuItem, Me.ListOfMedicineDistributionToolStripMenuItem, Me.ListOfSuppliersToolStripMenuItem, Me.ListOfDoctorsToolStripMenuItem, Me.ListsOfSuppliersToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.medical_report_icon
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(89, 24)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'ListOfMedicineToolStripMenuItem
        '
        Me.ListOfMedicineToolStripMenuItem.Name = "ListOfMedicineToolStripMenuItem"
        Me.ListOfMedicineToolStripMenuItem.Size = New System.Drawing.Size(253, 24)
        Me.ListOfMedicineToolStripMenuItem.Text = "List of Medicines "
        '
        'ListOfMedicineDistributionToolStripMenuItem
        '
        Me.ListOfMedicineDistributionToolStripMenuItem.Name = "ListOfMedicineDistributionToolStripMenuItem"
        Me.ListOfMedicineDistributionToolStripMenuItem.Size = New System.Drawing.Size(253, 24)
        Me.ListOfMedicineDistributionToolStripMenuItem.Text = "List Distributed Medicines"
        '
        'ListOfSuppliersToolStripMenuItem
        '
        Me.ListOfSuppliersToolStripMenuItem.Name = "ListOfSuppliersToolStripMenuItem"
        Me.ListOfSuppliersToolStripMenuItem.Size = New System.Drawing.Size(253, 24)
        Me.ListOfSuppliersToolStripMenuItem.Text = "List of Stocks In"
        '
        'ListOfDoctorsToolStripMenuItem
        '
        Me.ListOfDoctorsToolStripMenuItem.Name = "ListOfDoctorsToolStripMenuItem"
        Me.ListOfDoctorsToolStripMenuItem.Size = New System.Drawing.Size(253, 24)
        Me.ListOfDoctorsToolStripMenuItem.Text = "List of Stocks Out"
        '
        'ListsOfSuppliersToolStripMenuItem
        '
        Me.ListsOfSuppliersToolStripMenuItem.Name = "ListsOfSuppliersToolStripMenuItem"
        Me.ListsOfSuppliersToolStripMenuItem.Size = New System.Drawing.Size(253, 24)
        Me.ListsOfSuppliersToolStripMenuItem.Text = "Lists of Suppliers"
        '
        'SystemToolsToolStripMenuItem
        '
        Me.SystemToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataBaseConnectionToolStripMenuItem, Me.CreateBackupToolStripMenuItem, Me.RetrieveToolStripMenuItem})
        Me.SystemToolsToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.TOOLS
        Me.SystemToolsToolStripMenuItem.Name = "SystemToolsToolStripMenuItem"
        Me.SystemToolsToolStripMenuItem.Size = New System.Drawing.Size(141, 24)
        Me.SystemToolsToolStripMenuItem.Text = "Technical Tools"
        '
        'DataBaseConnectionToolStripMenuItem
        '
        Me.DataBaseConnectionToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.connection
        Me.DataBaseConnectionToolStripMenuItem.Name = "DataBaseConnectionToolStripMenuItem"
        Me.DataBaseConnectionToolStripMenuItem.Size = New System.Drawing.Size(227, 24)
        Me.DataBaseConnectionToolStripMenuItem.Text = "Data Base Connection"
        '
        'CreateBackupToolStripMenuItem
        '
        Me.CreateBackupToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.bup
        Me.CreateBackupToolStripMenuItem.Name = "CreateBackupToolStripMenuItem"
        Me.CreateBackupToolStripMenuItem.Size = New System.Drawing.Size(227, 24)
        Me.CreateBackupToolStripMenuItem.Text = "Create Backup"
        '
        'RetrieveToolStripMenuItem
        '
        Me.RetrieveToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.retrieve
        Me.RetrieveToolStripMenuItem.Name = "RetrieveToolStripMenuItem"
        Me.RetrieveToolStripMenuItem.Size = New System.Drawing.Size(227, 24)
        Me.RetrieveToolStripMenuItem.Text = "Retrieve "
        '
        'AboutHelpToolStripMenuItem
        '
        Me.AboutHelpToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.INFO
        Me.AboutHelpToolStripMenuItem.Name = "AboutHelpToolStripMenuItem"
        Me.AboutHelpToolStripMenuItem.Size = New System.Drawing.Size(79, 24)
        Me.AboutHelpToolStripMenuItem.Text = "About"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.QUESTION
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(69, 24)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip1.BackgroundImage = Global.MEDICINE_INVENTORY.My.Resources.Resources.Button_Bkg
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 484)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(915, 25)
        Me.StatusStrip1.TabIndex = 8
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(103, 20)
        Me.ToolStripStatusLabel1.Text = "User name :  "
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(85, 20)
        Me.ToolStripStatusLabel3.Text = "User Type:"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(112, 20)
        Me.ToolStripStatusLabel2.Text = "System Time : "
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel4.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(167, 20)
        Me.ToolStripStatusLabel4.Text = "ToolStripStatusLabel4"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackgroundImage = Global.MEDICINE_INVENTORY.My.Resources.Resources.bac8
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 96)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(915, 388)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.MEDICINE_INVENTORY.My.Resources.Resources.Pill_spinning_128
        Me.PictureBox1.Location = New System.Drawing.Point(3, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(909, 369)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Adminfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(915, 509)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.DoubleBuffered = True
        Me.Name = "Adminfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MAIN MENU"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MedicalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefferalLetterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccountSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RetrieveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateBackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataBaseConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfDoctorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfSuppliersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfMedicineDistributionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfMedicineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DateModifiedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SortbyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SmallIconToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ScreenResolutionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GadgetsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PersonalizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents DataEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents AccountsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewUserAccountToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MangeUserAccountsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ManageMedicinesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfMedicinesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemainingStocksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfSuppliersToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListsOfSuppliersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox

End Class
