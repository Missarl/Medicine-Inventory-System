﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class distribute_meedicine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.np = New System.Windows.Forms.TextBox()
        Me.ag = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ad = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.da = New System.Windows.Forms.DateTimePicker()
        Me.qu = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.mn = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.rs = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.se = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label1.Location = New System.Drawing.Point(14, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(122, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name of Patient"
        '
        'np
        '
        Me.np.Font = New System.Drawing.Font("Century", 11.25!)
        Me.np.Location = New System.Drawing.Point(142, 43)
        Me.np.Name = "np"
        Me.np.Size = New System.Drawing.Size(316, 26)
        Me.np.TabIndex = 1
        '
        'ag
        '
        Me.ag.Font = New System.Drawing.Font("Century", 11.25!)
        Me.ag.Location = New System.Drawing.Point(142, 73)
        Me.ag.Name = "ag"
        Me.ag.Size = New System.Drawing.Size(93, 26)
        Me.ag.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label2.Location = New System.Drawing.Point(14, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 18)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Age"
        '
        'ad
        '
        Me.ad.Font = New System.Drawing.Font("Century", 11.25!)
        Me.ad.Location = New System.Drawing.Point(142, 104)
        Me.ad.Multiline = True
        Me.ad.Name = "ad"
        Me.ad.Size = New System.Drawing.Size(316, 77)
        Me.ad.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label3.Location = New System.Drawing.Point(14, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label4.Location = New System.Drawing.Point(241, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 18)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Sex"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label5.Location = New System.Drawing.Point(14, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(42, 18)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Date"
        '
        'da
        '
        Me.da.Font = New System.Drawing.Font("Century", 11.25!)
        Me.da.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.da.Location = New System.Drawing.Point(142, 13)
        Me.da.Name = "da"
        Me.da.Size = New System.Drawing.Size(200, 26)
        Me.da.TabIndex = 9
        '
        'qu
        '
        Me.qu.Font = New System.Drawing.Font("Century", 11.25!)
        Me.qu.Location = New System.Drawing.Point(153, 304)
        Me.qu.Name = "qu"
        Me.qu.Size = New System.Drawing.Size(106, 26)
        Me.qu.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label6.Location = New System.Drawing.Point(14, 304)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(71, 18)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Quantity"
        '
        'mn
        '
        Me.mn.Font = New System.Drawing.Font("Century", 11.25!)
        Me.mn.Location = New System.Drawing.Point(142, 230)
        Me.mn.Name = "mn"
        Me.mn.ReadOnly = True
        Me.mn.Size = New System.Drawing.Size(267, 26)
        Me.mn.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label7.Location = New System.Drawing.Point(14, 238)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(118, 18)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Medicine Name"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(415, 228)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(43, 28)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(17, 349)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 36)
        Me.Button2.TabIndex = 15
        Me.Button2.Text = "Add More"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(133, 349)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(100, 36)
        Me.Button3.TabIndex = 16
        Me.Button3.Text = "Save"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(245, 349)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(100, 36)
        Me.Button4.TabIndex = 17
        Me.Button4.Text = "Reset"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(358, 349)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(100, 36)
        Me.Button5.TabIndex = 18
        Me.Button5.Text = "Close"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'rs
        '
        Me.rs.Font = New System.Drawing.Font("Century", 11.25!)
        Me.rs.Location = New System.Drawing.Point(153, 266)
        Me.rs.Name = "rs"
        Me.rs.ReadOnly = True
        Me.rs.Size = New System.Drawing.Size(106, 26)
        Me.rs.TabIndex = 20
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century", 11.25!)
        Me.Label8.Location = New System.Drawing.Point(14, 274)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(134, 18)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Remaining Stocks"
        '
        'se
        '
        Me.se.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.se.Font = New System.Drawing.Font("Century", 11.25!)
        Me.se.FormattingEnabled = True
        Me.se.Items.AddRange(New Object() {"Male", "Female"})
        Me.se.Location = New System.Drawing.Point(295, 72)
        Me.se.Name = "se"
        Me.se.Size = New System.Drawing.Size(142, 26)
        Me.se.TabIndex = 21
        '
        'distribute_meedicine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(470, 399)
        Me.Controls.Add(Me.se)
        Me.Controls.Add(Me.rs)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.mn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.qu)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.da)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ad)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ag)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.np)
        Me.Controls.Add(Me.Label1)
        Me.Name = "distribute_meedicine"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MEDICINE DISTRIBUTION"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents np As System.Windows.Forms.TextBox
    Friend WithEvents ag As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ad As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents da As System.Windows.Forms.DateTimePicker
    Friend WithEvents qu As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents mn As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents rs As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents se As System.Windows.Forms.ComboBox
End Class
